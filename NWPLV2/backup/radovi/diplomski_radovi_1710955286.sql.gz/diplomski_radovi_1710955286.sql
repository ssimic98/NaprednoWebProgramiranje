INSERT INTO diplomski_radovi (ID,naziv_rada,tekst_rada,link_rada,oib_tvrtke)
VALUES ('332', 'Tema za završni i diplomski rad &#8211; Web aplikacija namijenjena vlasnicima pasa kao kućnih ljubimaca', 'Tema je namijenjena studentima stručnog studija, preddiplomskog studija ili diplomskog studija. 

Promjene u načinu života i trendovi promijenili su način razmišljanja o konceptu kućnog ljubimca. Oni su postali sastavni dio čovjekovog života pružajući bezuvjetnu naklonost i sigurnost doprinoseći psihološkoj dobrobiti svojih vlasnika. 

Radom je potrebno izraditi web aplikaciju koja bi vlasnicima pasa omogućila lakšu komunikaciju i informiranje o njihovim karakteristikama i potrebama. Proizvođačima proizvoda za kućne ljubimce  bi se omogućila platforma za reklamiranje proizvoda i informiranje o njihovim performansama. Uzgajivačima pasa bi se omogućio lakši dolazak do kupaca. 

Stručnim osobama, poput veterinara te edukatora za odgoj pasa, kineziološkom savezu te raznim udrugama za zaštitu životinja također bi bila pružena mogućnost za lakšu interakciju s korisnicima usluga, no isto tako i onima koji pružaju razne druge usluge poput šetača pasa ili salona za šišanje pasa. Osnovne tehnologije koje bi bile korištene za izradu web aplikacije su: HTML, JavaScript (ili neki razvojni okvir temeljen na JavaScript-u), PHP (Hypertext Preprocessor), te MySQL sustav za upravljanje bazom podataka. Web aplikacija treba biti izrađena u Laravel razvojnom okruženju. 

Osim same aplikacije i opisa tehnologija putem kojih je izrađena potrebno je analizirati potrebu za ovakvim proizvodom. 

Mentorica:prof.dr.sc. Dominika Crnjac Milić (FERIT); sumentori:izv.prof.dr.sc. Krešimir Nenadić (FERIT)  &#8211; Factory mentor: Alen Juren', 'https://stup.ferit.hr/2021/11/19/tema-za-zavrsni-i-diplomski-rad-web-aplikacija-namijenjena-vlasnicima-pasa-kao-kucnih-ljubimaca/', '2147483647');
INSERT INTO diplomski_radovi (ID,naziv_rada,tekst_rada,link_rada,oib_tvrtke)
VALUES ('333', 'Tema za završni i diplomski rad – Potpora zbrinjavanju otpada putem informatičko komunikacijske tehnologije', 'Tema je namijenjena studentima stručnog studija, preddiplomskog studija ili diplomskog studija. 

Zbrinjavanje otpada postaje problem čijem rješavanju se sve više posvećuju znanstveni i stručni krugovi, kao i šira javnost. Korporativna društvena odgovornost, održivost i svijest o okolišu sve se više mijenjaju na bolje, no još uvijek postoji mogućnost za napredak. 

Sve kraći vijek trajanja bijele tehnike i ostalih uređaja prisutnih u kućanstvu, ali i u proizvodnji generira veliku količinu otpada čije zbrinjavanje iziskuje velika financijske troškove te predstavlja značajan problem onima koji te proizvode trebaju otpremiti na reciklažna dvorišta. 

Kao doprinos razvoju odgovornosti pojedinaca potrebno je napraviti web aplikaciju putem koje bi pravne i fizičke osobe mogle objaviti sliku i detalje o uređaju za rashod. Aplikacija bi također pružala mogućnost interakcije s poduzećima i fizičkim osobama koje uređaj žele preuzeti u svrhu korištenja njegovih dijelova ili u svrhu upcycling -a (davanja uređajima novu svrhu i novo ruho). Jednostavno bi mogli dogovoriti vrijeme i način preuzimanja uređaja i samim time bi se osigurala razmjena dobara na obostranu korist. 

Dizajn kao i druge funkcionalnosti aplikacije mogu se napraviti po slobodnom izboru. Prilikom izrade web aplikacije potrebno je voditi brigu da se aplikacija može koristiti i na mobilnim uređajima te je potrebno primijeniti responzivni dizajn korisničkog sučelja s &#8216;mobile first&#8217; pristupom. 

Radom je također potrebno ukazati koliko su recikliranje i održivost važni u procesu odlučivanja o kupnji. 

Mentorica: prof.dr.sc. Dominika Crnjac Milić (FERIT); sumentori: izv.prof.dr.sc. Krešimir Nenadić (FERIT) &#8211; Factory mentor: Dino Turopoli', 'https://stup.ferit.hr/2021/11/19/tema-za-zavrsni-i-diplomski-rad-potpora-zbrinjavanju-otpada-putem-informaticko-komunikacijske-tehnologije/', '2147483647');
INSERT INTO diplomski_radovi (ID,naziv_rada,tekst_rada,link_rada,oib_tvrtke)
VALUES ('334', 'Javna rasvjeta u funkciji marketing aktivnosti', '(Tema je namijenjena studentima i studenticama diplomskog, preddiplomskog studija i stručnog studija) 

  

Urbane sredine sve više prepoznaju mogućnosti korištenja javne rasvjete za promicanje svog vizualnog identiteta. Isto tako implementiranim marketinškim rješenjima se osigurava financijska samoodrživost javne rasvjete. Zadatak rada je ukazati na mogućnost financijske održivosti javne rasvjete iznajmljivanjem reklamnog prostora putem led displaya. Opisati tehničku izvedbu tih rješenja, izraditi analizu troškova izvedbe te opisati način mogućih financijskih ušteda njihovim korištenjem. 

  

Mentorica: Prof.dr.sc. Dominika Crnjac Milić; Sumentori: Ivica Čabraja, mag.ing.el. (ET projekt 

d.o.o. za projektiranje i nadzor) i  Zorislav Kraus dipl.ing., viši predavač (FERIT Osijek)', 'https://stup.ferit.hr/2021/01/29/javna-rasvjeta-u-funkciji-marketing-aktivnosti/', '2147483647');
INSERT INTO diplomski_radovi (ID,naziv_rada,tekst_rada,link_rada,oib_tvrtke)
VALUES ('335', 'Ekonomska i energetska učinkovitost pametnog upravljanja javnom rasvjetom', '(Tema je namijenjena studentima i studenticama diplomskog, preddiplomskog studija i stručnog studija) 

Zadatak rada je analizirati tehnički i ekonomski aspekt primjene novih rješenja javne rasvjete. Napraviti usporedbu s tradicionalnim izvedbama u smislu energetske učinkovitosti te dugoročno održivim financijskim uštedama. Na primjeru iz prakse izraditi troškovnik ugradnje jednog rješenja, te opisati tehničku izvedbu. 

&nbsp; 

Mentorica: Prof.dr.sc. Dominika Crnjac Milić; Sumentori:Ivica Čabraja, mag.ing.el. (ET projekt 

d.o.o. za projektiranje i nadzor) i  Zorislav Kraus dipl.ing., viši predavač (FERIT Osijek)', 'https://stup.ferit.hr/2021/01/29/ekonomska-i-energetska-ucinkovitost-pametnog-upravljanja-javnom-rasvjetom/', '2147483647');
INSERT INTO diplomski_radovi (ID,naziv_rada,tekst_rada,link_rada,oib_tvrtke)
VALUES ('336', 'Rasvijetljenost pješačkih prijelaza i svjetlosna signalizacija s tehničkog i ekonomskog aspekta', '(Tema je namijenjena studentima i studenticama diplomskog, preddiplomskog studija i stručnog studija) 

Sve intenzivniji promet i složenija prometna infrastruktura utječu na potrebu za novim rješenjima vezanim za sigurnost u prometu. Zadatak ovog rada je istražiti, analizirati i opisati tehnička rješenja rasvijetljenosti i signalizacije pješačkih prijelaza. Ukazati na moguće financijske uštede koje se postižu implementacijom „pametnih“ rješenja. Za jedno takvo rješenje potrebno je opisati tehničku izvedbu i izraditi troškovnik ugradnje. 

Mentorica: Prof.dr.sc. Dominika Crnjac Milić; Sumentori:Ivica Čabraja, mag.ing.el. (ET projekt 

d.o.o. za projektiranje i nadzor) i  Zorislav Kraus dipl.ing., viši predavač (FERIT Osijek)', 'https://stup.ferit.hr/2021/01/29/rasvijetljenost-pjesackih-prijelaza-i-svjetlosna-signalizacija-s-tehnickog-i-ekonomskog-aspekta/', '2147483647');
INSERT INTO diplomski_radovi (ID,naziv_rada,tekst_rada,link_rada,oib_tvrtke)
VALUES ('337', 'Tema za diplomski rad', 'NASLOV: Emulacija energetskog pretvarača za baterijske spremnike energije 

Mentor: Prof. dr. sc. Denis Pelin 

Sumentor: Kristijan Lolić (Rimac Automobili d.o.o.) 

ZADATAK: Pregled energetskih pretvarača za baterijske spremnike. Razvoj simulacijskog moela u programskom okruženju Typhoon HIL. Parametarske analize energetskog dijela pretavrača. Razvoj upravljačkog dijela pretvarača pomoću mikrokontrolera i vanjske upravljačke pločice.', 'https://stup.ferit.hr/2021/01/29/tema-za-diplomski-rad-2/', '2147483647');
